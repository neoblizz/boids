using UnityEngine;
using System.Collections;
 
public class predatorMove : MonoBehaviour {
 
    public Vector3 bound;
    public float speed = 3.0f;
    public float delta = 2.0f;

    private Transform target;
    private Vector3 initialPosition;
    private Vector3 lastPosition;
    private Vector3 nextMovementPoint;
 
    void Start () {
        initialPosition = transform.position;
        CalculateNextMovementPoint();
        transform.position = nextMovementPoint;
        //lastPosition = transform.position;
        target = transform.parent;
    }
    
    void Update () {
        nextMovementPoint = target.position;
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(nextMovementPoint - transform.position), 2 * Time.deltaTime);

    }
 
    void CalculateNextMovementPoint()
    {	
    	//print(nextMovementPoint);
    	//print(nextMovementPoint);
        float posX = Random.Range(initialPosition.x - bound.x, initialPosition.x + bound.x);
        float posY = Random.Range(initialPosition.y - bound.y, initialPosition.y + bound.y);
        float posZ = Random.Range(initialPosition.z - bound.z, initialPosition.z + bound.z);
        nextMovementPoint = initialPosition + new Vector3(posX, posY, posZ);
    }
}