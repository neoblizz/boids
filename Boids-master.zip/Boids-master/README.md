# Boids

A little experiment with boids in Unity:
https://www.youtube.com/watch?v=bqtqltqcQhw

For a much better implemented and performant version in Unity, have a look at the ECS sample project:
https://github.com/Unity-Technologies/EntityComponentSystemSamples/tree/master/ECSSamples/Assets/Advanced/Boids/Scripts

![Boids](https://i.imgur.com/Q1E488u.png)
